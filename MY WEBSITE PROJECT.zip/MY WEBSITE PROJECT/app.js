/* =========================================================
   Be The Light of the World – shared app script
   Layout shell, auth (localStorage), blur lock, animations
   ========================================================= */
(function () {
  'use strict';

  var KEY_USERS = 'btl_users';
  var KEY_SESSION = 'btl_session';

  var PAGES = [
    { id: 'reflection',    href: 'index.html',         icon: 'scroll', label: 'REFLECTION' },
    { id: 'portfolio',     href: 'portfolio.html',     icon: 'user',   label: 'PORTFOLIO' },
    { id: 'community',     href: 'community.html',     icon: 'users',  label: 'COMMUNITY' },
    { id: 'informational', href: 'informational.html', icon: 'book',   label: 'INFORMATIONAL' },
    { id: 'faith',         href: 'faith-tech.html',    icon: 'cross',  label: 'FAITH &amp; TECH <br>INTEGRATION' }
  ];

  /* ---------- Inline SVG icons (replaces Font Awesome) ---------- */
  var ICONS = {
    scroll: '<path d="M8 21h10a3 3 0 0 0 3-3v-1H11v1a3 3 0 0 1-3 3zm0 0a3 3 0 0 1-3-3V5a2 2 0 0 0-2-2h13a2 2 0 0 1 2 2v12"/><path d="M9 8h6M9 12h6"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    book: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    cross: '<path d="M10 2h4v6h6v4h-6v10h-4V12H4V8h6z"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
    star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    pin: '<path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
    target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    sun: '<circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/>',
    leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.5 2 8 0 5.5-4.8 10-10 10z"/><path d="M2 21c0-3 1.9-5.5 6-8"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
    code: '<path d="M16 18l6-6-6-6M8 6l-6 6 6 6"/>',
    id: '<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="11" r="2"/><path d="M14 10h5M14 14h4M5 16c.5-1.5 1.5-2 3-2s2.5.5 3 2"/>',
    phone: '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
    video: '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    chevron: '<path d="M6 9l6 6 6-6"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>',
    refresh: '<path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15"/>',
    pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    gift: '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M19 12v9H5v-9M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
    bulb: '<path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.7.6 1 1.4 1 2.3h6c0-.9.3-1.7 1-2.3A7 7 0 0 0 12 2z"/>'
  };

  function icon(name) {
    return '<svg class="svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  }
  function hydrate(root) {
    (root || document).querySelectorAll('[data-icon]').forEach(function (el) {
      if (!el.dataset.done) { el.innerHTML = icon(el.dataset.icon); el.dataset.done = '1'; }
    });
  }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var $ = function (s, r) { return (r || document).querySelector(s); };

  /* ---------- Storage helpers ---------- */
  function read(k, d) {
    try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; }
  }
  function write(k, v) {
    try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; }
  }

  /* ---------- Auth ---------- */
  async function hash(pw, salt) {
    var data = salt + ':' + pw;
    if (window.crypto && crypto.subtle && window.TextEncoder) {
      try {
        var buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
        return Array.from(new Uint8Array(buf)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
      } catch (e) { /* fall through */ }
    }
    var h = 5381;
    for (var i = 0; i < data.length; i++) h = ((h << 5) + h) ^ data.charCodeAt(i);
    return 'f' + (h >>> 0).toString(16);
  }
  function getUsers() { return read(KEY_USERS, []); }
  function currentUser() {
    var s = read(KEY_SESSION, null);
    if (!s) return null;
    var u = getUsers().find(function (x) { return x.email === s.email; });
    return u ? { name: u.name, email: u.email } : null;
  }
  async function signup(name, email, pw) {
    var users = getUsers();
    email = email.toLowerCase();
    if (users.some(function (u) { return u.email === email; })) return { ok: false, field: 'email', msg: 'An account with this email already exists.' };
    if (users.some(function (u) { return u.name.toLowerCase() === name.toLowerCase(); })) return { ok: false, field: 'name', msg: 'That username is already taken.' };
    var salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
    users.push({ name: name, email: email, salt: salt, passHash: await hash(pw, salt), created: Date.now() });
    if (!write(KEY_USERS, users)) return { ok: false, msg: 'Could not save your account. Please enable browser storage.' };
    write(KEY_SESSION, { email: email });
    return { ok: true };
  }
  async function login(id, pw) {
    id = id.trim().toLowerCase();
    var u = getUsers().find(function (x) { return x.email === id || x.name.toLowerCase() === id; });
    if (!u) return { ok: false, field: 'id', msg: 'No account found. Try signing up first.' };
    if ((await hash(pw, u.salt)) !== u.passHash) return { ok: false, field: 'pw', msg: 'Incorrect password. Please try again.' };
    write(KEY_SESSION, { email: u.email });
    return { ok: true };
  }
  function logout() {
    try { localStorage.removeItem(KEY_SESSION); } catch (e) {}
    applyAuth();
    toast('You have been logged out. Stay shining! 🕯️');
  }

  /* ---------- Toast ---------- */
  var toastBox;
  function toast(msg) {
    if (!toastBox) { toastBox = document.createElement('div'); toastBox.className = 'toasts'; toastBox.setAttribute('aria-live', 'polite'); document.body.appendChild(toastBox); }
    var t = document.createElement('div');
    t.className = 'toast'; t.textContent = msg;
    toastBox.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 320); }, 2800);
  }

  /* ---------- Logo SVG ---------- */
  var LOGO = '<svg id="logo" viewBox="0 0 750 750" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Light of the World logo">' +
    '<g id="wreathGroup"><g id="leavesLeft"></g><g id="leavesRight"></g></g><g id="stars"></g>' +
    '<g id="centerEmblem"><g id="flameGroup"><path id="flame" fill="#dd3d28" d="M345,234 C339,198 323,178 330,148 C334,130 349,122 345,98 C362,121 355,140 368,158 C372,147 370,134 375,124 C380,134 378,147 382,158 C395,140 388,121 405,98 C401,122 416,130 420,148 C427,178 411,198 405,234 Z"/></g>' +
    '<g id="torchGroup"><path fill="#2b2b2b" d="M330,228 L420,228 C420,246 402,240 392,268 L358,268 C348,240 330,246 330,228 Z"/><path fill="#2b2b2b" d="M360,268 L390,268 L382,420 L375,496 L368,420 Z"/><path fill="#cfcfcf" d="M371,478 L379,478 L375,496 Z"/></g>' +
    '<g id="bookLeft" class="book-half"><path fill="#2b2b2b" d="M355,300 C292,282 196,292 170,332 C150,364 164,396 208,420 C252,444 318,460 372,494 C346,462 332,430 336,396 C339,364 347,330 355,300 Z"/><path fill="none" stroke="#f3f1ec" stroke-width="4" stroke-linecap="round" d="M344,306 C292,296 215,308 192,338"/><path fill="none" stroke="#f3f1ec" stroke-width="4" stroke-linecap="round" d="M352,316 C305,310 236,322 206,352"/></g>' +
    '<g id="bookRight" class="book-half"><path fill="#2b2b2b" d="M395,300 C458,282 554,292 580,332 C600,364 586,396 542,420 C498,444 432,460 378,494 C404,462 418,430 414,396 C411,364 403,330 395,300 Z"/><path fill="none" stroke="#f3f1ec" stroke-width="4" stroke-linecap="round" d="M406,306 C458,296 535,308 558,338"/><path fill="none" stroke="#f3f1ec" stroke-width="4" stroke-linecap="round" d="M398,316 C445,310 514,322 544,352"/></g></g></svg>';

  function buildLogo() {
    var NS = 'http://www.w3.org/2000/svg', cx = 375, cy = 375;
    function polar(r, deg) { var rad = deg * Math.PI / 180; return { x: cx + r * Math.sin(rad), y: cy - r * Math.cos(rad) }; }
    var leafD = 'M0,0 C-6,-3 -7,-11 0,-18 C7,-11 6,-3 0,0 Z';
    function leaves(side) {
      var group = document.getElementById(side === -1 ? 'leavesLeft' : 'leavesRight');
      var rows = [
        { rBase: 300, count: 15, sMin: 0.6, sMax: 1.35, off: 0 },
        { rBase: 268, count: 14, sMin: 0.45, sMax: 1.05, off: 0.12 }
      ];
      var idx = 0;
      rows.forEach(function (row) {
        for (var i = 0; i < row.count; i++) {
          var t = i / (row.count - 1);
          var angle = side === -1 ? (-34 - 148 * t) : (34 + 148 * t);
          var size = row.sMin + (row.sMax - row.sMin) * t;
          var p = polar(row.rBase + (i % 2 === 0 ? 6 : -4), angle);
          var rot = side === -1 ? angle + 100 : angle - 100;
          var g = document.createElementNS(NS, 'g');
          g.setAttribute('transform', 'translate(' + p.x.toFixed(2) + ',' + p.y.toFixed(2) + ') rotate(' + rot.toFixed(2) + ') scale(' + size.toFixed(2) + ')');
          var path = document.createElementNS(NS, 'path');
          path.setAttribute('d', leafD);
          path.setAttribute('fill', t > 0.55 ? '#1f4d3a' : '#6f7f5f');
          path.setAttribute('class', 'leaf');
          path.style.animationDelay = (0.05 + idx * 0.025 + row.off).toFixed(3) + 's';
          g.appendChild(path); group.appendChild(g); idx++;
        }
      });
    }
    function starPath(o, n) {
      var d = '';
      for (var i = 0; i < 10; i++) {
        var r = i % 2 === 0 ? o : n, a = (-90 + i * 36) * Math.PI / 180;
        d += (i === 0 ? 'M' : 'L') + (r * Math.cos(a)).toFixed(2) + ',' + (r * Math.sin(a)).toFixed(2) + ' ';
      }
      return d + 'Z';
    }
    leaves(-1); leaves(1);
    var sg = document.getElementById('stars');
    [{ x: 265, y: 185, d: 0.9 }, { x: 485, y: 185, d: 0.95 }, { x: 300, y: 272, d: 1.05 }, { x: 450, y: 272, d: 1.1 }].forEach(function (p) {
      var g = document.createElementNS(NS, 'g');
      g.setAttribute('transform', 'translate(' + p.x + ',' + p.y + ')');
      var path = document.createElementNS(NS, 'path');
      path.setAttribute('d', starPath(20, 8));
      path.setAttribute('fill', '#cf9f3f');
      path.setAttribute('class', 'star');
      path.style.animationDelay = p.d + 's, ' + (p.d + 1.2) + 's';
      g.appendChild(path); sg.appendChild(g);
    });
  }

  /* ---------- Shell (header / menu / footer / modal) ---------- */
  var current = document.body.dataset.page;
  var listeners = [];

  function buildShell() {
    // clouds
    var clouds = $('.clouds');
    if (clouds && !clouds.children.length) {
      for (var i = 0; i < 6; i++) {
        var s = document.createElement('span');
        var w = 30 + Math.random() * 30;
        s.style.cssText = 'width:' + w + 'vw;height:' + (w * 0.42) + 'vw;left:' + (Math.random() * 90 - 15) + 'vw;top:' + (Math.random() * 85 - 8) + 'vh;animation-duration:' + (38 + Math.random() * 40).toFixed(0) + 's;animation-delay:-' + (Math.random() * 30).toFixed(0) + 's;opacity:' + (0.5 + Math.random() * 0.4).toFixed(2);
        clouds.appendChild(s);
      }
    }

    $('#header').innerHTML =
      '<div class="navbar">' +
        '<a class="brand" href="index.html" aria-label="Be the Light of the World – home">' +
          '<div class="stage">' + LOGO + '</div>' +
          '<div class="headertxt"><h1>Be the Light of the World!</h1><h4>UNA ANG GINOO</h4></div>' +
        '</a>' +
        '<div class="buttons" id="authButtons"></div>' +
      '</div>';

    $('#sidebar').innerHTML = '<div class="menu"><nav id="links" aria-label="Main navigation">' +
      PAGES.map(function (p) {
        return '<a href="' + p.href + '" class="link' + (p.id === current ? ' active" aria-current="page' : '') + '">' + icon(p.icon) + '<span>' + p.label + '</span></a>';
      }).join('') + '</nav></div>';

    $('#footer').innerHTML = '<div class="footbar">' +
      '<div class="devinfo"><h5>' + icon('code') + 'DEVELOPED BY GERALI</h5><h5>' + icon('id') + 'SECTION 32</h5></div>' +
      '<div class="note">“Let your light so shine before men.” — Matthew 5:16</div></div>';

    // content wrap + lock overlay
    var lock = $('#lock');
    if (lock) {
      lock.innerHTML = '<div class="lock-card" role="dialog" aria-label="Login required">' +
        '<div class="lock-ico">' + icon('lock') + '</div>' +
        '<h2>This page is for members</h2>' +
        '<p>Create a free account or log in to read and enjoy this content. Your account is saved safely in this browser.</p>' +
        '<div class="row"><button class="btn alt" data-auth="signup">Sign Up</button><button class="btn" data-auth="login">Log In</button></div></div>';
    }

    // staggered pop-in on load
    [['#header', 0], ['#sidebar', 0.2], ['#center', 0.35], ['#footer', 0.55]].forEach(function (a) {
      var el = $(a[0]); if (!el) return;
      el.classList.add('pop'); el.style.setProperty('--pd', a[1] + 's');
    });

    buildLogo();
    buildModal();
    hydrate();
  }

  function renderButtons(u) {
    var box = $('#authButtons');
    if (!box) return;
    if (u) {
      box.innerHTML = '<div class="hello"><div class="avatar">' + esc(u.name.charAt(0).toUpperCase()) + '</div><span class="nm">Hi, ' + esc(u.name) + '</span></div>' +
        '<button class="btn-log" id="logoutBtn" type="button">' + icon('logout') + ' LOG OUT</button>';
    } else {
      box.innerHTML = '<button class="btn-sign" type="button" data-auth="signup">SIGN UP</button><button class="btn-log" type="button" data-auth="login">LOG IN</button>';
    }
  }

  function applyAuth() {
    var u = currentUser();
    document.body.classList.toggle('locked', !u);
    var c = $('#content');
    if (c) {
      if (u) c.removeAttribute('inert'); else c.setAttribute('inert', '');
      c.setAttribute('aria-hidden', String(!u));
    }
    renderButtons(u);
    listeners.forEach(function (fn) { try { fn(u); } catch (e) { console.error(e); } });
  }

  /* ---------- Auth modal ---------- */
  var modal, lastFocus, tab = 'login';

  function buildModal() {
    modal = document.createElement('div');
    modal.className = 'modal-backdrop'; modal.hidden = true;
    modal.innerHTML =
      '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="authTitle">' +
        '<button class="modal-close" type="button" aria-label="Close">&times;</button>' +
        '<div class="modal-logo">' + icon('sun') + ' Light of the World</div>' +
        '<h2 id="authTitle"></h2><p class="sub" id="authSub"></p>' +
        '<div class="tabs" role="tablist"><button type="button" data-tab="signup" role="tab">Sign Up</button><button type="button" data-tab="login" role="tab">Log In</button></div>' +
        '<form id="signupForm" novalidate autocomplete="on">' +
          '<label class="field"><span>Username</span><input name="name" type="text" autocomplete="username" maxlength="24" placeholder="e.g. lightbearer"><small class="err"></small></label>' +
          '<label class="field"><span>Email</span><input name="email" type="email" autocomplete="email" placeholder="you@example.com"><small class="err"></small></label>' +
          '<label class="field"><span>Password</span><input name="pw" type="password" autocomplete="new-password" placeholder="At least 6 characters"><small class="err"></small></label>' +
          '<label class="field"><span>Confirm password</span><input name="pw2" type="password" autocomplete="new-password" placeholder="Repeat your password"><small class="err"></small></label>' +
          '<label class="show-pw"><input type="checkbox" class="spw"> Show passwords</label>' +
          '<button class="btn alt" type="submit">Create my account</button><div class="form-msg" role="alert"></div>' +
          '<div class="switch">Already have an account? <button type="button" data-tab="login">Log in</button></div>' +
        '</form>' +
        '<form id="loginForm" novalidate autocomplete="on">' +
          '<label class="field"><span>Username or email</span><input name="id" type="text" autocomplete="username" placeholder="Your username or email"><small class="err"></small></label>' +
          '<label class="field"><span>Password</span><input name="pw" type="password" autocomplete="current-password" placeholder="Your password"><small class="err"></small></label>' +
          '<label class="show-pw"><input type="checkbox" class="spw"> Show password</label>' +
          '<button class="btn" type="submit">Log in</button><div class="form-msg" role="alert"></div>' +
          '<div class="switch">New here? <button type="button" data-tab="signup">Create an account</button></div>' +
        '</form>' +
      '</div>';
    document.body.appendChild(modal);

    modal.addEventListener('mousedown', function (e) { if (e.target === modal) closeModal(); });
    $('.modal-close', modal).addEventListener('click', closeModal);
    modal.querySelectorAll('[data-tab]').forEach(function (b) { b.addEventListener('click', function () { setTab(b.dataset.tab); }); });
    modal.querySelectorAll('.spw').forEach(function (cb) {
      cb.addEventListener('change', function () {
        cb.closest('form').querySelectorAll('input[type=password],input[data-pw]').forEach(function (i) {
          i.type = cb.checked ? 'text' : 'password'; i.dataset.pw = '1';
        });
      });
    });
    $('#signupForm').addEventListener('submit', onSignup);
    $('#loginForm').addEventListener('submit', onLogin);
    modal.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeModal(); return; }
      if (e.key === 'Tab') {
        var f = Array.from(modal.querySelectorAll('button,input,select,textarea')).filter(function (x) { return x.offsetParent !== null; });
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }

  function clearErrors(form) {
    form.querySelectorAll('.field').forEach(function (f) { f.classList.remove('invalid'); $('.err', f).textContent = ''; });
    $('.form-msg', form).textContent = '';
  }
  function setErr(form, name, msg) {
    var input = form.elements[name];
    if (!input) { $('.form-msg', form).textContent = msg; return; }
    var f = input.closest('.field'); f.classList.add('invalid'); $('.err', f).textContent = msg;
  }
  function setTab(t) {
    tab = t;
    var isSign = t === 'signup';
    $('#authTitle').textContent = isSign ? 'Join the light' : 'Welcome back';
    $('#authSub').textContent = isSign ? 'Create an account to unlock every page.' : 'Log in to continue your journey.';
    modal.querySelectorAll('.tabs [data-tab]').forEach(function (b) {
      var on = b.dataset.tab === t; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on));
    });
    $('#signupForm').hidden = !isSign;
    $('#loginForm').hidden = isSign;
    clearErrors($('#signupForm')); clearErrors($('#loginForm'));
    var form = isSign ? $('#signupForm') : $('#loginForm');
    setTimeout(function () { var i = form.querySelector('input'); if (i && modal.classList.contains('open')) i.focus(); }, 60);
  }
  function openModal(t) {
    lastFocus = document.activeElement;
    modal.hidden = false;
    setTab(t || 'login');
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function () { requestAnimationFrame(function () { modal.classList.add('open'); setTimeout(function () { var f = (t === 'signup' ? $('#signupForm') : $('#loginForm')).querySelector('input'); if (f) f.focus(); }, 80); }); });
  }
  function closeModal() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
    setTimeout(function () { modal.hidden = true; }, 260);
    if (lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) {} }
  }

  async function onSignup(e) {
    e.preventDefault();
    var f = e.target; clearErrors(f);
    var name = f.elements.name.value.trim(), email = f.elements.email.value.trim(), pw = f.elements.pw.value, pw2 = f.elements.pw2.value;
    var bad = false;
    if (name.length < 3) { setErr(f, 'name', 'Username must be at least 3 characters.'); bad = true; }
    else if (!/^[\w .-]+$/.test(name)) { setErr(f, 'name', 'Use letters, numbers, spaces, . _ - only.'); bad = true; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { setErr(f, 'email', 'Please enter a valid email address.'); bad = true; }
    if (pw.length < 6) { setErr(f, 'pw', 'Password must be at least 6 characters.'); bad = true; }
    if (pw2 !== pw) { setErr(f, 'pw2', 'Passwords do not match.'); bad = true; }
    if (bad) return;
    var btn = $('button[type=submit]', f); btn.disabled = true;
    var r = await signup(name, email, pw);
    btn.disabled = false;
    if (!r.ok) { setErr(f, r.field, r.msg); return; }
    f.reset(); closeModal(); applyAuth();
    toast('Welcome, ' + name + '! Your account is ready ✨');
  }
  async function onLogin(e) {
    e.preventDefault();
    var f = e.target; clearErrors(f);
    var id = f.elements.id.value.trim(), pw = f.elements.pw.value, bad = false;
    if (!id) { setErr(f, 'id', 'Enter your username or email.'); bad = true; }
    if (!pw) { setErr(f, 'pw', 'Enter your password.'); bad = true; }
    if (bad) return;
    var btn = $('button[type=submit]', f); btn.disabled = true;
    var r = await login(id, pw);
    btn.disabled = false;
    if (!r.ok) { setErr(f, r.field, r.msg); return; }
    f.reset(); closeModal(); applyAuth();
    var u = currentUser();
    toast('Welcome back, ' + (u ? u.name : '') + '! 🕯️');
  }

  /* ---------- Global events ---------- */
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-auth]');
    if (a) { e.preventDefault(); openModal(a.dataset.auth); return; }
    if (e.target.closest('#logoutBtn')) { logout(); return; }
    // smooth page leave
    var link = e.target.closest('a[href]');
    if (link && !e.defaultPrevented && !e.metaKey && !e.ctrlKey && !e.shiftKey && link.target !== '_blank') {
      var href = link.getAttribute('href');
      if (/^[\w-]+\.html$/.test(href) && !link.classList.contains('active')) {
        e.preventDefault();
        document.body.classList.add('leaving');
        setTimeout(function () { location.href = href; }, 230);
      }
    }
  });
  window.addEventListener('pageshow', function () { document.body.classList.remove('leaving'); });
  window.addEventListener('storage', function (e) { if (e.key === KEY_SESSION || e.key === KEY_USERS) applyAuth(); });

  /* ---------- Scroll reveal + counters ---------- */
  var io;
  function runCount(el) {
    if (el.dataset.done) return; el.dataset.done = '1';
    var t0 = performance.now(), dur = 1400;
    (function step(now) {
      var p = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - p, 3), to = parseInt(el.dataset.to || '0', 10);
      el.textContent = Math.round(to * e).toLocaleString();
      if (p < 1) requestAnimationFrame(step); else el.textContent = parseInt(el.dataset.to || '0', 10).toLocaleString();
    })(t0);
  }
  function show(el) {
    el.classList.add('in');
    if (el.classList.contains('count')) runCount(el);
    el.querySelectorAll('.count').forEach(runCount);
  }
  function reveal(root) {
    var els = (root || document).querySelectorAll('.reveal');
    els.forEach(function (el, i) {
      if (el.dataset.obs) return; el.dataset.obs = '1';
      if (!el.style.getPropertyValue('--d')) el.style.setProperty('--d', Math.min((i % 6) * 0.07, 0.4) + 's');
      if (io) io.observe(el); else show(el);
    });
  }
  if ('IntersectionObserver' in window) {
    io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { show(en.target); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });
  }

  /* ---------- Public API for page scripts ---------- */
  window.BTL = {
    user: currentUser,
    onAuth: function (fn) { listeners.push(fn); try { fn(currentUser()); } catch (e) { console.error(e); } },
    toast: toast, icon: icon, hydrate: hydrate, esc: esc, read: read, write: write,
    reveal: reveal, openAuth: openModal, users: getUsers
  };

  /* ---------- Init ---------- */
  buildShell();
  applyAuth();
  reveal();
})();
